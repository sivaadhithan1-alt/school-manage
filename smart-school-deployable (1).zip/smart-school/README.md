# Smart School — Next.js School Management System

A modern school management web app (dashboards for students, teachers, parents and admins)
including attendance (QR-scan), homework, exams, complaints, circulars, charts and an AI chat
assistant.

Built with **Next.js 14 (App Router)**, **React 18**, **Tailwind CSS**, **Recharts**,
**lucide-react**. Works fully on bundled **mock data**, so it runs with **no external services
required** — Supabase and Google Gemini are optional extras.

## ✅ Ready to deploy to Netlify

The build is verified working (`npm run build` succeeds; app runs with `npm run start`).

### Quick deploy with Git

1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. In **Netlify** → **Add new site** → **Import an existing project**.
3. Select the repo. Netlify auto-detects Next.js and reads `netlify.toml`.
   - Build command: `npm run build`
   - Publish directory: `.next`
   - It uses the official **`@netlify/plugin-nextjs`** runtime (in `netlify.toml`) so your
     API routes (`/api/scan`, `/api/ai/chat`) work — this is **not** a static export.
4. **Deploy**. The site is live at `https://<your-site>.netlify.app`.

### Deploy via drag-and-drop (no Git)

Netlify needs the server-side runtime for the API routes, so for a simple drag-and-drop you
must first produce the Netlify-compatible build locally:

```bash
npm install
npm run build
npx netlify deploy --prod --dir=.next
```

(Requires the `netlify-cli` and `npm i -D @netlify/plugin-nextjs`.)

## Environment variables (all optional)

Create `.env.local` from `.env.example` (or set these in Netlify → Site settings → Environment):
none are required — the app falls back to bundled mock data.

| Variable | Purpose |
|----------|---------|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase project URL (real auth/DB) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service role key |
| `GEMINI_API_KEY` | Enables live AI chat (offline answers used otherwise) |
| `NEXT_PUBLIC_APP_URL` | Public site URL |

## Local development

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # production build
npm run start    # run the production build
```

## Logging in (demo mode)

The auth is localStorage-based with demo accounts. Use password `password123`:

- `student@smartschool.com` (Student)
- `teacher@smartschool.com` (Teacher)
- `parent@smartschool.com` (Parent)
- `admin@smartschool.com` (Admin)

The login page has one-click role buttons that fill these in. After login you're routed to the
matching role dashboard.

## Routes

| Route | Description |
|-------|-------------|
| `/` | Teacher/student dashboard (protected) |
| `/login` | Sign in |
| `POST /api/scan` | QR-code attendance scan (mock data) |
| `POST /api/ai/chat` | AI chat assistant |

## Project structure

```
src/
├── app/
│   ├── layout.tsx            # root layout (html/body, globals.css)
│   ├── globals.css           # Tailwind + design tokens
│   ├── (dashboard)/
│   │   ├── layout.tsx        # protected layout (auth + sidebar/header)
│   │   └── page.tsx          # staff student-directory dashboard
│   ├── login/page.tsx        # sign-in page
│   └── api/
│       ├── scan/route.ts     # QR attendance API
│       └── ai/chat/route.ts  # AI chat API
├── components/
│   ├── layout/               # sidebar, header, dashboard-layout, page-header
│   └── ui/                   # button, card, table, charts, qr-code-view, ai-chat-box…
└── lib/
    ├── types.ts              # shared TypeScript types
    ├── mock-data.ts          # seed/demo data
    ├── index.ts              # utils
    ├── auth/context.tsx      # AuthProvider + useAuth
    ├── client.ts             # Supabase browser client (optional)
    └── server.ts             # Supabase server client (optional)
```

## Notes

- The original `.zip` was a flattened, incomplete export. It has been reconstructed into the
  proper `src/` App-Router structure, including the missing `types.ts`, root `layout.tsx`,
  `/login` page and the `/api/ai/chat` route, and configured for Netlify (`netlify.toml`).
- DB schemas come with the project: `20260826000000_initial_schema.sql` and `seed.sql`.
