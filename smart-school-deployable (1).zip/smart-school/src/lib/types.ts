// ============================================================
// SMART SCHOOL — Shared TypeScript Types
// ============================================================

export type Role = 'student' | 'teacher' | 'parent' | 'admin';
export type Status = 'active' | 'inactive' | 'suspended';

// --- Base profile ---

export interface Profile {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  profile_photo: string | null;
  role: Role;
  date_of_birth: string;
  gender: 'male' | 'female' | 'other';
  address: string;
  status: string;
  created_at: string;
  updated_at: string;
}

// --- Student ---

export interface Student {
  id: string;
  profile_id: string;
  student_id: string;
  admission_number: string;
  roll_number: number;
  standard: number;
  section: string;
  academic_year: string;
  date_of_birth: string;
  qr_token: string;
  guardian_name: string;
  guardian_phone: string;
  guardian_email: string;
  guardian_relation: string;
  blood_group: string;
  status: string;
  created_at: string;
  updated_at: string;
}

// --- Teacher ---

export interface Teacher {
  id: string;
  profile_id: string;
  employee_id: string;
  department: string;
  designation: string;
  joining_date: string;
  qualification: string;
  specialization: string;
  status: string;
  created_at: string;
  updated_at: string;
}

// --- Academic ---

export interface Subject {
  id: string;
  name: string;
  code: string;
  subject_type: string;
  standard: number;
  academic_year: string;
  description: string | null;
}

export interface Class {
  id: string;
  standard: number;
  section: string;
  academic_year: string;
  class_teacher_id: string | null;
  room_number: string;
}

export interface PeriodConfig {
  id: string;
  period_number: number;
  name: string;
  start_time: string;
  end_time: string;
  is_break: boolean;
  academic_year: string;
}

export interface TimetableEntry {
  id: string;
  class_id: string;
  day_of_week: number;
  period_number: number;
  subject_id: string;
  teacher_id: string;
  room: string;
}

// --- Homework ---

export interface Homework {
  id: string;
  class_id: string;
  subject_id: string;
  teacher_id: string;
  title: string;
  description: string;
  due_date: string;
  attachment_url: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  // Denormalized fields present in development mock data
  subject?: Subject;
  subject_name?: string;
  teacher?: Teacher;
  teacher_name?: string;
}

// --- School events & circulars ---

export interface SchoolEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  start_time: string;
  end_time: string;
  venue: string;
  image_url: string | null;
  category: string;
  created_by: string;
  visibility: string;
  status: string;
  created_at: string;
}

export interface Circular {
  id: string;
  title: string;
  description: string;
  category: string;
  published_by: string;
  published_at: string;
  attachment_url: string | null;
  visibility: string;
  created_at: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: string;
  student_ids: string[] | null;
  team_name: string | null;
  level: string;
  date: string;
  image_url: string | null;
  published_by: string;
  created_at: string;
}

// --- Complaints ---

export interface Complaint {
  id: string;
  complaint_number: string;
  student_id: string;
  category: string;
  title: string;
  description: string;
  location: string;
  attachment_url: string | null;
  priority: string;
  status: string;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
}

// --- Notifications ---

export interface Notification {
  id: string;
  recipient_id: string;
  title: string;
  message: string;
  type: string;
  reference_id: string | null;
  is_read: boolean;
  created_at: string;
}

// --- Attendance ---

export interface AttendanceRecord {
  id: string;
  student_id: string;
  date: string;
  period: number;
  status: 'present' | 'absent' | 'late' | 'leave';
  subject_id?: string;
  teacher_id?: string;
  method?: string;
  marked_by?: string;
  created_at?: string;
}

export interface AttendanceSession {
  id: string;
  class_id: string;
  subject_id: string;
  teacher_id: string;
  date: string;
  period: number;
  status: string;
  student_ids: string[];
  created_at: string;
}

// --- Exams & marks ---

export interface Exam {
  id: string;
  name: string;
  academic_year: string;
  standard: number;
  start_date: string;
  end_date: string;
  status: string;
  created_at: string;
}

export interface ExamSubject {
  id: string;
  exam_id: string;
  subject_id: string;
  exam_date: string;
  start_time: string;
  end_time: string;
  maximum_marks: number;
  passing_marks: number;
}

export interface Mark {
  id: string;
  student_id: string;
  exam_subject_id: string;
  marks_obtained: number;
  grade: string;
  remarks: string | null;
  entered_by: string;
  updated_at: string;
}

export interface Ranking {
  id: string;
  student_id: string;
  exam_id: string;
  category: string;
  standard: number;
  section: string;
  rank: number;
  total_marks: number;
  total_max_marks: number;
  percentage: number;
  is_published: boolean;
  published_at: string;
}

// --- Activities ---

export interface StudentActivity {
  id: string;
  student_id: string;
  title: string;
  category: string;
  description: string;
  date: string;
  result: string;
  certificate_url: string | null;
  created_by: string;
  created_at: string;
}
