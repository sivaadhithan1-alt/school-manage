import { NextRequest, NextResponse } from 'next/server';

// Optional Gemini integration — falls back to a smart offline responder when
// GEMINI_API_KEY is not configured.
export async function POST(req: NextRequest) {
  try {
    const { message, role } = await req.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ message: 'Please provide a query.' }, { status: 400 });
    }

    const q = message.toLowerCase();

    // Try live Gemini if a key is set.
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const { GoogleGenerativeAI } = await import('@google/generative-ai');
        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
        const prompt = `You are the Smart School assistant. The current user role is "${role}". Answer concisely and helpfully in 2-3 sentences.\n\nStudent question: ${message}`;
        const result = await model.generateContent(prompt);
        const text = result.response.text();
        return NextResponse.json({ message: text });
      } catch (e) {
        console.error('Gemini error:', e);
        // fall through to offline answer
      }
    }

    const answer = offlineAnswer(q, role);
    return NextResponse.json({ message: answer });
  } catch (error) {
    console.error('AI chat error:', error);
    return NextResponse.json(
      { message: 'Sorry, something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}

function offlineAnswer(q: string, role?: string): string {
  if (q.includes('homework')) {
    return 'Today’s homework: Mathematics — “Quadratic Equations, Exercise 4.3” (due 28 Aug). Science — read Chapter 5 and note key definitions.';
  }
  if (q.includes('timetable') || q.includes('schedule')) {
    return 'Period 1: Mathematics · Period 2: Physics (Lab 1) · Period 3: English · Period 4: Chemistry (Lab 2) · Period 5: Social Science. Lunch at 12:00.';
  }
  if (q.includes('exam') || q.includes('test')) {
    return 'Next up: Mid-Term Examination from 20 Sep to 5 Oct. The detailed subject-wise timetable is published in the Circulars section.';
  }
  if (q.includes('attendance')) {
    return 'Your attendance this term is 90% (present 108 of 120 days). Keep it up — above 75% is required to sit the exams.';
  }
  if (q.includes('complaint')) {
    return 'To raise a complaint, go to the Complaints page, pick a category (infrastructure, water, academic, etc.) and submit the details. Staff will update you.';
  }
  if (q.includes('event') || q.includes('activity')) {
    return 'Next event: Annual Science Exhibition on 15 Sep at the School Auditorium, open to classes 8–12. You can register through your dashboard.';
  }
  return `Hi${role ? ` (${role})` : ''}! I’m your Smart School assistant. I can help with homework, timetable, exams, attendance, complaints and events. Ask me anything.`;
}
