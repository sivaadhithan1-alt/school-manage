import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Smart School — School Management System',
  description:
    'A modern school management system with student, teacher, parent and admin dashboards.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
