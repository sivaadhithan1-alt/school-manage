/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },
  experimental: {
    serverActions: {
      // Allow the app to run on localhost and any Netlify preview/production URL.
      allowedOrigins: [
        'localhost:3000',
        'localhost:3001',
        '*.netlify.app',
        '*.netlify.com',
      ],
    },
  },
};

module.exports = nextConfig;
